import {
  Mic,
  Sliders,
  AudioWaveform,
  ChevronDown,
  ArrowRight,
} from "lucide-react";
import IconButton from "./IconButton";

export default function MainInput() {
  return (
    <div className="w-full rounded-2xl bg-neutral-900/70 p-[1px] ]">
      <div className="rounded-2xl bg-neutral-950 p-4">
        <input
          placeholder="Describe your song"
          className="w-full bg-transparent text-sm text-neutral-200 placeholder:text-neutral-500 focus:outline-none"
        />

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <IconButton icon={<Mic size={16} />} />
            <IconButton icon={<Sliders size={16} />} />
            <IconButton icon={<AudioWaveform size={16} />} />

            <button className="ml-2 rounded-full border border-white/10 px-3 py-1 text-xs text-neutral-300 hover:bg-white/5">
              + Lyrics
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1 rounded-full border border-white/10 px-3 py-1 text-xs text-neutral-300 hover:bg-white/5">
              Tools
              <ChevronDown size={14} />
            </button>

            <button className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 shadow-lg text-neutral-300 hover:text-white transition-colors duration-150 hover:bg-gradient-to-br hover:from-orange-500 hover:to-purple-600">
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
