export default function RecentGenerations() {
  return (
    <div className="w-full space-y-4">
      <h2 className="text-sm font-medium text-neutral-300">
        Recent generations
      </h2>

      <div className="space-y-2">
        <Item
          title="Crimson Echoes"
          description="Create a pop-rock song about old times, nostalgic opera theme style, guitar solo like slash"
        />
        <Item
          title="Don't look back in anger, Sally"
          description="Classic Brit-rock inspired emotional anthem"
        />
      </div>
    </div>
  );
}

function Item({ title, description }: { title: string; description: string }) {
  return (
    <div className="flex cursor-pointer items-center gap-3 rounded-xl p-2 hover:bg-white/5">
      <div className="h-10 w-10 rounded-md bg-neutral-800" />
      <div>
        <p className="text-sm text-neutral-200">{title}</p>
        <p className="text-xs text-neutral-500 line-clamp-1">{description}</p>
      </div>
    </div>
  );
}
