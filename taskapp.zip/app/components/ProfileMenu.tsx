"use client";

import React, { useEffect, useRef, useState } from "react";
import ProfileDropdown from "./ProfileDropDown";

export default function ProfileMenu() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  return (
    <div ref={ref} className="absolute top-4 right-6 z-50">
      <button
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="true"
        className="relative flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-gradient-to-br from-purple-500 to-pink-500 shadow-md focus:outline-none"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600 via-pink-500 to-orange-500 rounded-full p-0.5">
          <div className="w-full h-full rounded-full bg-[#1d2125] flex items-center justify-center">
            <span className="text-white text-xl">J</span>
          </div>
        </div>

        <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-green-400 text-[10px] font-semibold text-white ring-2 ring-black animate-border-blink">
          2<span className="sr-only">2 new notifications</span>
        </span>
      </button>

      {open && (
        <>
          <ProfileDropdown isOpen={open} onClose={() => setOpen(false)} />
        </>
      )}
    </div>
  );
}
