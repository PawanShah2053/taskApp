import MainInput from "./components/MainInput";
import RecentGenerations from "./components/RecentGenerations";
import Sidebar from "./components/Sidebar";
import ProfileMenu from "./components/ProfileMenu";

export default function HomePage() {
  return (
    <main className="relative flex h-screen w-screen overflow-hidden  ">
      <ProfileMenu />
      <Sidebar />

      <section className="relative flex flex-1 items-center justify-center">
        <div className="absolute " />

        <div className="relative z-10 flex w-full max-w-3xl flex-col items-center gap-10 mt-50 px-6">
          <h1 className="text-3xl font-semibold tracking-tight text-neutral-100">
            What Song to Create?
          </h1>
          <div className="w-full">
            <MainInput />
            <div className="mt-2 text-sm text-neutral-500 text-center">
              <p>
                MusicGPT v6 Pro - Our latest AI audio model{" "}
                <a href="#" className="underline cursor-pointer text-current">
                  Example prompts
                </a>
              </p>
            </div>
          </div>

          <div className="w-full mt-30">
            <RecentGenerations />
          </div>
        </div>
      </section>
    </main>
  );
}
